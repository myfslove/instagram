<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOOK'S</title>
    <link rel="icon" href="yyy.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <style>
.zoom {
 
  transition: transform .2s; /* Animation */
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.3); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

nav {
    text-shadow: 3px 2px 1px grey;
    font-size: 40px;
}                        

body {
  background-image: url('www.jpg');
  background-position: absolute;
  background-size: 1350px;
}
</style>
</head>
<center>
<body>
<div class="wrapper">
        <div class="logo">
            <img src="yyy.png" alt="">
        </div>
        <div class="text-center mt-4 name">
            BOOK'S
        </div>
        <br>
        <form action="proses_login.php" method="post">
        <form class="p-3 mt-3">
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="text" name="username" id="username" required placeholder="username">
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="password" name="password" id="password" required placeholder="password">
            </div>
            <button class="btn mt-3">Login</button>
        </form>
    </form>
</body>
</center>
</html>