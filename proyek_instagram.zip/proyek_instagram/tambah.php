<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>BOOK'S</title>
    <link rel="icon" href="yyy.png">
</head>
<body>
<div class="container">
    <center>
    <h2>TAMBAH POSTINGAN</h2>
</center>
<br>
<br>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
    <label for="">Gambar</label><br>
    <input type="file" name="gambar" id="" class="form-control" required><br>

    <label for="">Caption</label><br>
    <input type="text" name="caption" id="" class="form-control" required><br>

    <label for="">Lokasi</label><br>
    <input type="text" name="lokasi" id="" class="form-control" required><br>

    <br>
    <input type="submit" value="Simpan" name="simpan" class="btn btn-primary">
</form>    
</div>
</body>
</html>